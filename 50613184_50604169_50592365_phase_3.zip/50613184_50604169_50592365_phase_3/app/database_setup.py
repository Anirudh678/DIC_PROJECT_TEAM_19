import sqlite3

# Connect to the database
connection = sqlite3.connect('recommendations.db')
cursor = connection.cursor()


cursor.execute('''
    CREATE TABLE IF NOT EXISTS recommendations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id TEXT,
        skin_type TEXT,
        budget REAL,
        primary_category TEXT,
        sub_category TEXT,
        label TEXT,
        product_name TEXT,
        rank REAL,
        price REAL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
''')

connection.commit()
connection.close()

print("Database and table with session_id created successfully.")
