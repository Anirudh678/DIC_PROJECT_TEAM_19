// document.getElementById('recommendForm').addEventListener('submit', async function (e) {
//     e.preventDefault();

//     const skinType = document.getElementById('skinType').value;
//     const budget = document.getElementById('budget').value;
//     const primaryCategory = document.getElementById('primaryCategory').value;
//     const subCategory = document.getElementById('subCategory').value;
//     const label = document.getElementById('label').value;

//     if (!budget || parseInt(budget) <= 0) {
//         alert('Please enter a valid budget greater than 0.');
//         return;
//     }

//     const payload = {
//         skin_type: skinType,
//         budget: parseFloat(budget),
//         primary_category: primaryCategory,
//         sub_category: subCategory,
//         label: label
//     };

//     try {
//         const response = await fetch('http://127.0.0.1:5000/recommend', {
//             method: 'POST',
//             headers: { 'Content-Type': 'application/json' },
//             body: JSON.stringify(payload)
//         });

//         if (response.ok) {
//             const data = await response.json();
//             displayResults(data);
//         } else {
//             const error = await response.json();
//             alert(error.error || 'An error occurred. Please try again.');
//         }
//     } catch (error) {
//         console.error('Error:', error);
//         alert('An error occurred. Please check the console for details.');
//     }
// });

// function displayResults(recommendations) {
//     const tableBody = document.getElementById('resultsTable').querySelector('tbody');
//     tableBody.innerHTML = '';

//     if (!recommendations.length) {
//         const row = document.createElement('tr');
//         row.innerHTML = '<td colspan="6">No recommendations found.</td>';
//         tableBody.appendChild(row);
//         return;
//     }

//     recommendations.forEach((rec) => {
//         const row = document.createElement('tr');
//         row.innerHTML = `
//             <td>${rec.ProductName}</td>
//             <td>${rec.PrimaryCategory}</td>
//             <td>${rec.SubCategory}</td>
//             <td>${rec.Label}</td>
//             <td>${rec.Rank.toFixed(2)}</td>
//             <td>$${rec.Price.toFixed(2)}</td>
//         `;
//         tableBody.appendChild(row);
//     });
// }
document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("recommendForm");
    const resultsTable = document.getElementById("resultsTable").querySelector("tbody");

    form.addEventListener("submit", async (event) => {
        event.preventDefault(); // Prevent default form submission and page reload

        // Gather form input values
        const skinType = document.getElementById("skinType").value;
        const budget = document.getElementById("budget").value;
        const primaryCategory = document.getElementById("primaryCategory").value;
        const subCategory = document.getElementById("subCategory").value;
        const label = document.getElementById("label").value;

        // Create JSON payload
        const requestData = {
            skin_type: skinType,
            budget: budget,
            primary_category: primaryCategory,
            sub_category: subCategory,
            label: label,
        };

        try {
            // Send a POST request to the Flask backend
            const response = await fetch("/recommend", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(requestData),
            });

            if (response.ok) {
                const recommendations = await response.json();
                displayRecommendations(recommendations);
            } else {
                const errorResponse = await response.json();
                alert(`Error: ${errorResponse.error || "Failed to fetch recommendations."}`);
            }
        } catch (error) {
            console.error("Error fetching recommendations:", error);
            alert("An unexpected error occurred. Please try again.");
        }
    });

    // Function to display recommendations in the table
    function displayRecommendations(recommendations) {
        // Clear previous results
        resultsTable.innerHTML = "";

        // Populate table with new recommendations
        recommendations.forEach((item) => {
            const row = document.createElement("tr");

            const cells = [
                item.ProductName,
                item.PrimaryCategory,
                item.SubCategory,
                item.Label,
                item.Rank,
                item.Price,
            ];

            cells.forEach((cellContent) => {
                const cell = document.createElement("td");
                cell.textContent = cellContent;
                row.appendChild(cell);
            });

            resultsTable.appendChild(row);
        });
    }
});
